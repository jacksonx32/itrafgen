/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package itrafgen.XMLPARSER;

/**
 *
 * @author sebastienhoerner
 */
public class choice {
	public String nom;
	public String value;
	//public String offset;
	public choice(String nom, String value) {
		//this.offset = offset;
		this.nom = nom;
		this.value = value;
	}

}