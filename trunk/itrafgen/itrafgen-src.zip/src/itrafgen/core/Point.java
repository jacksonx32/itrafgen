/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package itrafgen.core;

/**
 *
 * @author sebastienhoerner
 */
public class Point {
	public long temps;
	public long latence;
	public Point(long temps, long latence) {

		this.temps = temps;
		this.latence = latence;
	}
}
